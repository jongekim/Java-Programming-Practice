final class Crocodile extends Reptile {

	Crocodile(String in_name, float in_weight)
	{
		super(in_name, in_weight);
	}
	
	String getFood()
	{
		return "Meat";
	}
}
